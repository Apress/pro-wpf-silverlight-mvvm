﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.ComponentModel;

using Model;

namespace $safeprojectname$
{
    public class CalculatorViewModel : INotifyPropertyChanged
    {
        public CalculatorViewModel(ICalculator calculator)
        {
            if (calculator == null)
            {
                throw new ArgumentNullException();
            }

            _calculator = calculator;
        }

        public ICommand AddCommand
        {
            get
            {
                if (_addCommand == null)
                {
                    _addCommand = new RelayCommand(param => Add(), param => CanAdd());
                }
                return _addCommand;
            }
        }

        private string _firstNumber;
        public string FirstNumber
        {
            get
            {
                return _firstNumber;
            }
            set
            {
                _firstNumber = value;
#if SILVERLIGHT
                _addCommand.UpdateCanExecuteChanged();
#endif
            }
        }

        private string _secondNumber;
        public string SecondNumber
        {
            get
            {
                return _secondNumber;
            }
            set
            {
                _secondNumber = value;
#if SILVERLIGHT
                _addCommand.UpdateCanExecuteChanged();
#endif
            }
        }

        private string _result;
        public string Result
        {
            get { return _result; }
            set
            {
                if (_result != value)
                {
                    _result = value;
                    PropertyChanged(this, new PropertyChangedEventArgs("Result"));
                }
            }
        }

        public void Add()
        {
            int firstNumber, secondNumber;
            if (int.TryParse(FirstNumber, out firstNumber) && int.TryParse(SecondNumber, out secondNumber))
            {
                try
                {
                    Result = _calculator.Add(firstNumber, secondNumber).ToString();
                }
                catch(OverflowException)
                {
                    Result = "Overflow Exception";
                }
            }
        }

        public bool CanAdd()
        {
            int firstNumber, secondNumber;
            return int.TryParse(FirstNumber, out firstNumber) && int.TryParse(SecondNumber, out secondNumber);
        }

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        private ICalculator _calculator;
        private RelayCommand _addCommand;        
    }
}
