﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Model;

namespace $safeprojectname$
{
    [TestClass]
    public class CalculatorTests
    {
        [TestInitialize]
        public void Init()
        {
            _calculator = new Calculator();
        }

        [TestMethod]
        public void TestAdditionOfTwoPositiveNumbers()
        {
            int firstNumber = 11;
            int secondNumber = 24;

            int result = _calculator.Add(firstNumber, secondNumber);

            Assert.AreEqual(result, 35);
        }

        [TestMethod]
        public void TestAdditionOfOnePositiveAndOneNegativeNumber()
        {
            int firstNumber = 11;
            int secondNumber = -23;

            int result = _calculator.Add(firstNumber, secondNumber);

            Assert.AreEqual(result, -12);
        }

        [TestMethod]
        public void TestAdditionOfTwoNegativeNumbers()
        {
            int firstNumber = -17;
            int secondNumber = -28;

            int result = _calculator.Add(firstNumber, secondNumber);

            Assert.AreEqual(result, -45);
        }

        [TestMethod]
        [ExpectedException(typeof(OverflowException))]
        public void TestAdditionOfNumbersAroundLowerBoundary()
        {
            int firstNumber = int.MinValue;
            int secondNumber = -1;

            int result = _calculator.Add(firstNumber, secondNumber);
        }

        [TestMethod]
        [ExpectedException(typeof(OverflowException))]
        public void TestAdditionOfNumbersAroundUpperBoundary()
        {
            int firstNumber = int.MaxValue;
            int secondNumber = 1;

            int result = _calculator.Add(firstNumber, secondNumber);
        }

        private ICalculator _calculator;
    }
}
