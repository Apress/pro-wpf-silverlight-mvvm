﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $safeprojectname$
{
    [TestClass]
    public class CalculatorViewModelTests
    {
        [TestInitialize]
        public void Init()
        {
            _fakeCalculator = new FakeCalculator();
            _viewModel = new CalculatorViewModel(_fakeCalculator);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestConstruction_WithoutCalculator()
        {
            new CalculatorViewModel(null);
        }

        [TestMethod]
        public void TestAdditionCommandEnabled_WithValidPositiveValues()
        {
            _viewModel.FirstNumber = "10";
            _viewModel.SecondNumber = "25";

            bool result = _viewModel.AddCommand.CanExecute(null);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void TestAdditionCommandEnabled_WithValidNegativeValues()
        {
            _viewModel.FirstNumber = "-10";
            _viewModel.SecondNumber = "-25";

            bool result = _viewModel.AddCommand.CanExecute(null);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void TestAdditionCommandDisabled_WithInvalidFirstNumber()
        {
            _viewModel.FirstNumber = "A";
            _viewModel.SecondNumber = "10";

            bool result = _viewModel.AddCommand.CanExecute(null);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TestAdditionCommandDisabled_WithInvalidSecondNumber()
        {
            _viewModel.FirstNumber = "10";
            _viewModel.SecondNumber = "A";

            bool result = _viewModel.AddCommand.CanExecute(null);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TestAdditionCommandDisabled_WithInvalidNumbers()
        {
            _viewModel.FirstNumber = "A";
            _viewModel.SecondNumber = "B";

            bool result = _viewModel.AddCommand.CanExecute(null);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TestAdditionCommand()
        {
            _viewModel.FirstNumber = "10";
            _viewModel.SecondNumber = "30";

            _fakeCalculator.ReturnValue = 40;

            string propertyName = string.Empty;
            _viewModel.PropertyChanged += (s, e) => { propertyName = e.PropertyName; };
            
            _viewModel.AddCommand.Execute(null);

            Assert.IsTrue(_fakeCalculator.AddWasCalled);
            Assert.AreEqual("40", _viewModel.Result);
            Assert.AreEqual("Result", propertyName);
        }

        [TestMethod]
        public void TestAdditionCommand_WithBoundaries()
        {
            _viewModel.FirstNumber = int.MaxValue.ToString();
            _viewModel.SecondNumber = "1";

            _fakeCalculator.ShouldThrowOverflowException = true;

            _viewModel.AddCommand.Execute(null);

            Assert.IsTrue(_fakeCalculator.AddWasCalled);
            Assert.AreEqual("Overflow Exception", _viewModel.Result);
        }

        FakeCalculator _fakeCalculator;
        CalculatorViewModel _viewModel;
    }
}
