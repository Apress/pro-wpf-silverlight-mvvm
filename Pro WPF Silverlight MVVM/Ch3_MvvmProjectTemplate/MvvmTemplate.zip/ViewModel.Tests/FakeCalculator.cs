﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;

namespace $safeprojectname$
{
    public class FakeCalculator : ICalculator
    {
        public bool AddWasCalled
        {
            get;
            private set;
        }

        public bool ShouldThrowOverflowException
        {
            get;
            set;
        }

        public int? ReturnValue
        {
            get;
            set;
        }

        public int Add(int x, int y)
        {
            AddWasCalled = true;

            if (ShouldThrowOverflowException)
            {
                throw new OverflowException();
            }
            if (ReturnValue.HasValue)
            {
                return ReturnValue.Value;
            }

            return 0;
        }
    }
}
