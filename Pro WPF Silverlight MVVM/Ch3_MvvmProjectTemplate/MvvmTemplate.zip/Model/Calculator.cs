﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$
{
    public class Calculator : ICalculator
    {
        public int Add(int x, int y)
        {
            checked
            {
                return x + y;
            }
        }
    }
}
