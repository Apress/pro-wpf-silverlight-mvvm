﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$
{
    public interface ICalculator
    {
        int Add(int x, int y);
    }
}
